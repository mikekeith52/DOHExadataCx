import cfg
import pandas as pd

cfg.create_config('EXADW_test_test')